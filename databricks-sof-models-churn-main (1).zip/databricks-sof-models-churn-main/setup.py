from setuptools import find_packages, setup

setup(
    name="sof-models-churn",
    description="Project to predict customer churn"
)